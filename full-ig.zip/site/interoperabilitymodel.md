regarding the information exchange between all actors, we can check the image below.  

<div>
{% include interoperabilitymodel.svg %}
</div>

As for the sequence, we have the following:  

<div>
{% include sequence_diagram.svg %}
</div>