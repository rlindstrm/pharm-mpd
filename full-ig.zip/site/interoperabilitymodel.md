The Pharmacy Interoperability Model provides the basis for the interactions needs that are supported by this publication.

<div>
{% include interoperabilitymodel.svg %}
</div>

.
