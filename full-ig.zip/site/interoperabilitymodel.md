regarding the information exchange between all actors, we can check the image below.  

{%include interoperabilitymodel.svg%}


As for the sequence, we have the following:  

