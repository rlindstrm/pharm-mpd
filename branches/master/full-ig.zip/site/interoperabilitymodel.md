regarding the information exchange between all actors, we can check the image below.  

