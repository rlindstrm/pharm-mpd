The Pharmacy Interoperability Model provides the basis for the interactions needs that are supported by this publication.

<div>{% include interoperabilitymodel.svg %}</div>
<br clear="all"/>

As for the sequence, we have the following:  

<div>{% include sequence_diagram.svg %}</div>
<br clear="all"/>