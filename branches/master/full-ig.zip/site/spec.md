### Specifications
These are the project specifications: