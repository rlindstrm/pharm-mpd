regarding the information exchange between all actors, we can check the image below.  


As for the sequence, we have the following:  

